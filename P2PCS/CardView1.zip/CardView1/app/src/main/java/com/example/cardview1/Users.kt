
package com.example.cardview1

class Users {
    var id: Int = 0
    var login: String? = null
}